from django.contrib import admin

# Register your models here.
# from .models import StudentDetail
# admin.site.register(StudentDetail)